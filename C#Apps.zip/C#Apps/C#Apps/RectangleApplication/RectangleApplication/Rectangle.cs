﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace RectangleApplication
{
   class Rectangle
    {
        //member variables
        internal double length;
        private double width;

        public void AcceptDetails()
        {
            length = 4.5;
            width = 3.5;
        }

        public double GetArea()
        {
            return length * width;
        }

        public void display()
        {
            // Can also be written as->  WriteLine("Length : " + length.ToString());
            WriteLine("Length : {0}", length);
            WriteLine("Width : {0}", width);
            WriteLine("Area : {0}", GetArea());
            ReadKey();
        }
    }

    class ExecuteRectangle
    {
         static void Main(string[] args)
        {
            Rectangle r = new Rectangle();

            r.length = 4.5;
            //r.AcceptDetails();
            //r.display();
            //ReadLine();
             
        }
    }
}
