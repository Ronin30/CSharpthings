﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace SquareApplication
{
    class Square
    {
        double length;
        double width;

        public void AcceptDetails()
        {
            length = 5.8;
            width = 5.8;
        }

        public double GetArea()
        {
            return length * width;
        }

        public void display()
        {
            WriteLine("Length : {0}", length);
            WriteLine("Width : {0}", width);
            WriteLine("Area : {0}", GetArea());
        }

        public void SquareRoot()
        {
            WriteLine("Enter in the displayed area : ");
            int Number = Convert.ToInt32(ReadLine());
            double SqrtNumber = Math.Sqrt(Number);
            WriteLine("Square root of {0} is: {1}", Number, SqrtNumber);
            ReadLine();
        }
    }

    class ExecuteSquare
    {
        static void Main(string[] args)
        {
            Square s = new Square();

            s.AcceptDetails();
            s.display();
            s.SquareRoot();
            ReadLine();
        }
    }
}