// Filename DebugOne2.cs
// This program outputs a large C#
using System.Text;
using System;
using static System.Console;

namespace DebugOne2
{

    class Program
    {
        static void Main()
        {
            WriteLine("CCCCC   #  #");
            WriteLine("C     ########");
            WriteLine("C       #  #");
            WriteLine("C     ########");
            WriteLine("CCCCC   #  #");
        }
    }
}