// Filename DebugOne4.cs
// This program outputs a recipe
using static System.Console;

namespace Ingredients {
    class DebugOne4
    {
        static void Main ()
        {
            WriteLine("Spinach dip:");
            WriteLine();
            WriteLine("1 package frozen chopped spinach");
            WriteLine("1 cup mayonaise");
            WriteLine("1 chopped onion");
            WriteLine();
            WriteLine("Mix ingredients together.");
            WriteLine("Chill and serve with chips.");
        }
    }
}
