// Filename DebugOne3.cs
// This program outputs directions to a party
using System;

namespace Directions {
    class DebugOne3
    {
        static void Main()
        {
            Console.WriteLine("Take Highway 51 north");
            Console.WriteLine("Exit at County Road H");
            Console.WriteLine("Go three blocks and make a right on School Street");
            Console.WriteLine("Go right at Elm");
            Console.WriteLine("Party is four houses down on the left");
        }
    }
}
