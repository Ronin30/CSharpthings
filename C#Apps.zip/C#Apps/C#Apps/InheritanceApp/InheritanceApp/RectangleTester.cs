﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceApp
{
    //Base Class

    class Shape
    {
        protected int width;
        protected int height;

        public void SetWidth(int w)
        {
            width = w;
        }

        public void SetHeight(int h)
        {
            height = h;
        }
    }

    //Derived Class

    class Rectangle : Shape
    {
       public int GetArea()
        {
            return (width * height);
        }
    }

    class RectangleTester
    {
        static void Main(string[] args)
        {
            Rectangle Rect = new Rectangle();

            Rect.SetWidth(5);
            Rect.SetHeight(7);

            // Print th area of the object.
            Console.WriteLine("Total area : {0}", Rect.GetArea());
            Console.ReadKey();
        }
    }
}
